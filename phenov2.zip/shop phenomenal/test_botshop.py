import json
import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, Bot
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
from typing import Dict, List, Tuple
from telegram.error import BadRequest

# Configuration du logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Configuration
BOT_TOKEN = '7657595223:AAGqSEtrMP-GEeqVTlT4uHrKeTVAyxebkW0'
NOTIF_BOT_TOKEN = '8006997376:AAHY2JAtBpFEU2kED1T7loPsYEInxyDQFU4'  # Token du bot secondaire pour les notifications
user_id_admin = 956533401  # Remplace par ton ID Telegram

# Fichiers de stockage
SOLDES_FICHIER = "soldes.json"
ADMINS_FICHIER = "admins.json"
CODES_PROMO_FICHIER = "codes_promo.json"

# Charger les admins depuis un fichier JSON
def charger_admins() -> set:
    try:
        if os.path.exists(ADMINS_FICHIER):
            with open(ADMINS_FICHIER, 'r') as f:
                return set(json.load(f))
    except json.JSONDecodeError as e:
        logger.error(f"Erreur lors du chargement du fichier JSON: {e}")
    return {user_id_admin}

# Sauvegarder les admins dans un fichier JSON
def sauvegarder_admins(admins: set) -> None:
    try:
        with open(ADMINS_FICHIER, 'w') as f:
            json.dump(list(admins), f)
    except Exception as e:
        logger.error(f"Erreur lors de la sauvegarde des admins : {e}")

# Charger les soldes depuis un fichier JSON
def charger_soldes() -> Dict[str, int]:
    try:
        if os.path.exists(SOLDES_FICHIER):
            with open(SOLDES_FICHIER, 'r') as f:
                return json.load(f)
    except json.JSONDecodeError as e:
        logger.error(f"Erreur lors du chargement du fichier JSON: {e}")
    return {}

# Sauvegarder les soldes dans un fichier JSON
def sauvegarder_soldes(user_soldes: Dict[str, int]) -> None:
    try:
        with open(SOLDES_FICHIER, 'w') as f:
            json.dump(user_soldes, f)
    except Exception as e:
        logger.error(f"Erreur lors de la sauvegarde des soldes : {e}")

# Charger les codes promos depuis un fichier JSON
def charger_codes_promo() -> Dict[str, int]:
    try:
        if os.path.exists(CODES_PROMO_FICHIER):
            with open(CODES_PROMO_FICHIER, 'r') as f:
                return json.load(f)
    except json.JSONDecodeError as e:
        logger.error(f"Erreur lors du chargement du fichier JSON: {e}")
    return {}

# Sauvegarder les codes promos dans un fichier JSON
def sauvegarder_codes_promo(codes_promo: Dict[str, int]) -> None:
    try:
        with open(CODES_PROMO_FICHIER, 'w') as f:
            json.dump(codes_promo, f)
    except Exception as e:
        logger.error(f"Erreur lors de la sauvegarde des codes promos : {e}")

# Initialisation
admins = charger_admins()
user_soldes: Dict[str, int] = charger_soldes()
panier: Dict[int, List[Dict[str, int]]] = {}
codes_promo: Dict[str, int] = charger_codes_promo()

# Fonction pour ajouter des crédits manuellement (par un admin)
def ajouter_credit(user_id: int, montant: int) -> None:
    user_soldes[str(user_id)] = user_soldes.get(str(user_id), 0) + montant
    sauvegarder_soldes(user_soldes)
    logger.info(f"Crédits ajoutés pour l'utilisateur {user_id}: {montant}€")

# Fonction pour vérifier si l'utilisateur est l'admin
def est_admin(user_id: int) -> bool:
    return user_id in admins

# Fonction pour générer le bouton "Retour au Menu"
def generer_bouton_retour_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]])

# Commande /start qui affiche le menu principal
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    solde = user_soldes.get(str(user_id), 0)

    # Menu utilisateur
    keyboard = [
        [InlineKeyboardButton("💳 Acheter des Produits", callback_data='acheter_produits')],
        [InlineKeyboardButton("💰 Recharge de Crédit", callback_data='recharge_credit')],
        [InlineKeyboardButton("🛒 Afficher le Panier", callback_data='panier')],
        [InlineKeyboardButton("👤 Mon Profil", callback_data='profil')],
        [InlineKeyboardButton("📱 Support", callback_data='support')],
        [InlineKeyboardButton("📖 Guide d'utilisation", callback_data='guide')],
        [InlineKeyboardButton("🎁 Promo Code", callback_data='promo_code')]
    ]
    
    # Ajouter des options admin si l'utilisateur est l'administrateur
    if est_admin(user_id):
        keyboard.append([InlineKeyboardButton("🛠️ Gérer les Utilisateurs", callback_data='gerer_utilisateurs')])
        keyboard.append([InlineKeyboardButton("📊 Voir les Statistiques", callback_data='voir_statistiques')])
        keyboard.append([InlineKeyboardButton("💸 Envoyer Crédit à un Utilisateur", callback_data='envoyer_credit')])
        keyboard.append([InlineKeyboardButton("👑 Gérer les Admins", callback_data='gerer_admins')])
        keyboard.append([InlineKeyboardButton("🎁 Gérer les Codes Promos", callback_data='gerer_codes_promo')])
    
    reply_markup = InlineKeyboardMarkup(keyboard)

    # Utilise update.message si disponible, sinon update.callback_query.message
    if update.message:
        message = update.message
    else:
        message = update.callback_query.message

    await message.reply_text(
        f"💳 BIENVENUE AU PHENOMENAL MARKET ! 💳\n\nVOTRE SOLDE ACTUEL EST DE **{solde}€**.\nCHOISISSEZ UNE OPTION :",
        reply_markup=reply_markup
    )

# Fonction pour afficher le profil de l'utilisateur
async def afficher_profil(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user_id = update.effective_user.id
    solde = user_soldes.get(str(user_id), 0)

    await query.answer()
    message = f"👤 PROFIL DE L'UTILISATEUR 👤\n\nID DU COMPTE : `{user_id}`\nSOLDE ACTUEL : **{solde}€**"
    await query.edit_message_text(message, reply_markup=generer_bouton_retour_menu())

# Fonction pour gérer l'envoi de crédits à un utilisateur
async def envoyer_credit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    context.user_data['action'] = 'envoyer_credit'
    await query.edit_message_text("💸 ENTREZ L'ID DE L'UTILISATEUR ET LE MONTANT À ENVOYER (FORMAT : `ID MONTANT`) :", reply_markup=generer_bouton_retour_menu())

# Fonction pour gérer les messages après la saisie des informations
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    action = context.user_data.get('action')
    text = update.message.text.strip()

    logger.info(f"Action en cours: {action}, Input utilisateur: {text}")

    if action == 'envoyer_credit':
        try:
            user_id_str, montant_str = text.split()
            user_id = int(user_id_str)
            montant = int(montant_str)

            # Ajouter le crédit à l'utilisateur spécifié
            ajouter_credit(user_id, montant)
            await update.message.reply_text(f"✅ {montant}€ a été ajouté au compte de l'utilisateur {user_id}.", reply_markup=generer_bouton_retour_menu())
        except ValueError:
            await update.message.reply_text("❌ FORMAT INVALIDE. VEUILLEZ ENTRER LE TEXTE SOUS LA FORME `ID MONTANT`.", reply_markup=generer_bouton_retour_menu())

        context.user_data.pop('action', None)  # Réinitialiser l'action après traitement

    elif action == 'ajouter_promo':
        try:
            code_promo, reduction_str = text.split()
            reduction = int(reduction_str)
            codes_promo[code_promo] = reduction
            sauvegarder_codes_promo(codes_promo)
            await update.message.reply_text(f"✅ Code promo `{code_promo}` avec une réduction de {reduction}% ajouté.", reply_markup=generer_bouton_retour_menu())
        except ValueError:
            await update.message.reply_text("❌ FORMAT INVALIDE. VEUILLEZ ENTRER LE TEXTE SOUS LA FORME `CODE_PROMO REDUCTION`.", reply_markup=generer_bouton_retour_menu())

        context.user_data.pop('action', None)  # Réinitialiser l'action après traitement

    elif action == 'supprimer_promo':
        code_promo = text.strip()
        if code_promo in codes_promo:
            del codes_promo[code_promo]
            sauvegarder_codes_promo(codes_promo)
            await update.message.reply_text(f"✅ Code promo `{code_promo}` supprimé.", reply_markup=generer_bouton_retour_menu())
        else:
            await update.message.reply_text(f"❌ Code promo `{code_promo}` non trouvé.", reply_markup=generer_bouton_retour_menu())

        context.user_data.pop('action', None)  # Réinitialiser l'action après traitement

    elif action == 'recharge':
        try:
            montant = int(text)
            if montant <= 0:
                raise ValueError("Montant invalide")

            # Log the recharge request
            logger.info(f"Recharge request by user {update.effective_user.id} for amount: {montant}€")

            # Créer un ticket et l'envoyer à tous les admins
            for admin_id in admins:
                try:
                    await context.bot.send_message(
                        chat_id=admin_id,
                        text=f"💸 DEMANDE DE RECHARGE :\n\nID DE L'UTILISATEUR : {update.effective_user.id}\nMONTANT : {montant}€"
                    )
                except Exception as e:
                    logger.error(f"Erreur lors de l'envoi de la demande de recharge à {admin_id}: {e}")

            # Envoyer la notification via un bot secondaire si nécessaire
            if NOTIF_BOT_TOKEN:
                try:
                    notif_bot = Bot(token=NOTIF_BOT_TOKEN)
                    for admin_id in admins:
                        await notif_bot.send_message(
                            chat_id=admin_id,
                            text=f"💸 DEMANDE DE RECHARGE VIA BOT SECONDAIRE :\n\nID DE L'UTILISATEUR : {update.effective_user.id}\nMONTANT : {montant}€"
                        )
                except Exception as e:
                    logger.error(f"Erreur lors de l'envoi de la notification via le bot secondaire : {e}")

            # Afficher les informations de paiement à l'utilisateur
            message = (
                f"💳 RECHARGE DE CRÉDIT : {montant}€\n\n"
                f"📲 VEUILLEZ ENVOYER LE PAIEMENT À L'UNE DES ADRESSES SUIVANTES :\n\n"
                f"ETH: `0x4bE5813B4c92771227393DD0Ab596B5987775De5`\n"
                f"LTC: `LXm5mdsLwTs3VHy3QuEZZ8LgfU7Lr2dRSS`\n"
                f"SOL: `5SUEAdQFyYbzgvYbJH3RHucXFYcsdkmpWP1zLFopo9Xq`\n\n"
                f"🕵️ *Après le paiement, contactez le support pour confirmer votre transaction.*"
            )
            await context.bot.send_message(chat_id=update.effective_user.id, text=message, reply_markup=generer_bouton_retour_menu())
        except ValueError as e:
            logger.warning(f"Montant invalide saisi par l'utilisateur {update.effective_user.id}: {e}")
            await update.message.reply_text("❌ MONTANT INVALIDE. VEUILLEZ ENTRER UN NOMBRE ENTIER POSITIF.", reply_markup=generer_bouton_retour_menu())

        context.user_data.pop('action', None)  # Réinitialiser l'action après traitement

# Fonction pour gérer les boutons
async def button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query

    try:
        await query.answer()  # Répondre immédiatement pour éviter l'expiration du query_id

    except BadRequest as e:
        if "query is too old" in str(e):
            logger.warning("Query trop ancienne pour être traitée, l'ignorant.")
            return
        else:
            logger.error(f"Erreur BadRequest non gérée : {e}")
            raise

    produit_selectionne = query.data

    if produit_selectionne == 'recharge_credit':
        context.user_data['action'] = 'recharge'
        await query.edit_message_text("💰 ENTREZ LE MONTANT QUE VOUS SOUHAITEZ RECHARGER :", reply_markup=generer_bouton_retour_menu())
    
    elif produit_selectionne == 'acheter_produits':  # Menu "Acheter des Produits"
        keyboard = [
            [InlineKeyboardButton("SCAMMA ⚖️", callback_data='1')],
            [InlineKeyboardButton("NL 📲", callback_data='2')],
            [InlineKeyboardButton("RDP 🌟", callback_data='3')],
            [InlineKeyboardButton("Mailist 📧", callback_data='4')],
            [InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("💳 CHOISISSEZ UNE CATÉGORIE DE PRODUIT :", reply_markup=reply_markup)

    elif produit_selectionne == '1':  # SCAMMA
        keyboard = [
            [InlineKeyboardButton("UPS 2024 📦 - 125€", callback_data='ups')],
            [InlineKeyboardButton("DHL 2024 🚚 - 125€", callback_data='dhl')],
            [InlineKeyboardButton("COLISSIMO 2024 📬 - 125€", callback_data='colissimo')],
            [InlineKeyboardButton("CHRONOPOST 2024 🚀 - 125€", callback_data='chronopost')],
            [InlineKeyboardButton("NETFLIX 2024 🎥 - 125€", callback_data='netflix')],
            [InlineKeyboardButton("AMELI 2024 🏥 - 125€", callback_data='ameli')],
            [InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("💳 PRODUITS SCAMMA DISPONIBLES :", reply_markup=reply_markup)

    elif produit_selectionne == '2':  # NL
        keyboard = [
            [InlineKeyboardButton("France 🇫🇷", callback_data='france_nl')],
            [InlineKeyboardButton("Étranger 🌏", callback_data='etranger_nl')],
            [InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📲 CHOISISSEZ VOTRE CATÉGORIE NL :", reply_markup=reply_markup)

    elif produit_selectionne == 'france_nl':
        keyboard = [
            [InlineKeyboardButton("NETFLIX 13€/k 🎥", callback_data='acheter_netflix_fr')],
            [InlineKeyboardButton("DUMP DOCTOLIB 5€/k 💉", callback_data='acheter_doctolib')],
            [InlineKeyboardButton("MICROSOFT CHECK 3€/k 🖥️", callback_data='acheter_microsoft')],
            [InlineKeyboardButton("AMAZON CHECK : 1,50€ 📦", callback_data='acheter_amazon')],
            [InlineKeyboardButton("↩️ Retour", callback_data='2')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🇫🇷 PRODUITS FRANCE NL :", reply_markup=reply_markup)

    elif produit_selectionne == 'etranger_nl':
        keyboard = [
            [InlineKeyboardButton("SUISSE CHECK 🇨🇭 3€", callback_data='acheter_suisse')],
            [InlineKeyboardButton("DEUTSH CHECK 🇩🇪 3€", callback_data='acheter_deutsh')],
            [InlineKeyboardButton("PORTUGAL CHECK 🇵🇹 3€", callback_data='acheter_portugal')],
            [InlineKeyboardButton("ESPAGNE CHECK 🇪🇸 3€", callback_data='acheter_espagne')],
            [InlineKeyboardButton("CANADA CHECK 🇨🇦 3€", callback_data='acheter_canada')],
            [InlineKeyboardButton("↩️ Retour", callback_data='2')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("🌏 PRODUITS ÉTRANGER NL :", reply_markup=reply_markup)

    elif produit_selectionne == '3':  # RDP
        keyboard = [
            [InlineKeyboardButton("RDP 1 mois 30€ + Plesk 🖥️", callback_data='rdp_1m')],
            [InlineKeyboardButton("RDP 3 mois 50€ + Plesk 🖥️", callback_data='rdp_3m')],
            [InlineKeyboardButton("RDP 6 mois 90€ + Plesk 🖥️", callback_data='rdp_6m')],
            [InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("💳 PRODUITS RDP DISPONIBLES :", reply_markup=reply_markup)

    elif produit_selectionne == '4':  # Mailist
        keyboard = [
            [InlineKeyboardButton("Idf 🇫🇷", callback_data='idf_mailist')],
            [InlineKeyboardButton("Belgique debounce 🇧🇪", callback_data='belgique_mailist')],
            [InlineKeyboardButton("Espagne 🇪🇸", callback_data='espagne_mailist')],
            [InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📧 CHOISISSEZ VOTRE MAILIST :", reply_markup=reply_markup)

    elif produit_selectionne == 'idf_mailist':  # Mailist Idf
        keyboard = [
            [InlineKeyboardButton("Gmail.com 🇫🇷 - 4€/k", callback_data='idf_gmail')],
            [InlineKeyboardButton("↩️ Retour", callback_data='4')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📧 MAILIST IDF :", reply_markup=reply_markup)

    elif produit_selectionne == 'belgique_mailist':  # Mailist Belgique
        keyboard = [
            [InlineKeyboardButton("Hotmail.be 🇧🇪 - 4€/k", callback_data='belgique_hotmail')],
            [InlineKeyboardButton("Live.be 🇧🇪 - 4€/k", callback_data='belgique_live')],
            [InlineKeyboardButton("↩️ Retour", callback_data='4')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📧 MAILIST BELGIQUE DEBOUNCE :", reply_markup=reply_markup)

    elif produit_selectionne == 'espagne_mailist':  # Mailist Espagne
        keyboard = [
            [InlineKeyboardButton("Hotmail.es 🇪🇸 - 4€/k", callback_data='espagne_hotmail')],
            [InlineKeyboardButton("Yahoo.es 🇪🇸 - 4€/k", callback_data='espagne_yahoo')],
            [InlineKeyboardButton("↩️ Retour", callback_data='4')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("📧 MAILIST ESPAGNE :", reply_markup=reply_markup)

    elif produit_selectionne.startswith(('ups', 'dhl', 'colissimo', 'chronopost', 'netflix', 'ameli', 'rdp_1m', 'rdp_3m', 'rdp_6m', 'acheter_netflix_fr', 'acheter_doctolib', 'acheter_microsoft', 'acheter_amazon', 'idf_gmail', 'belgique_hotmail', 'belgique_live', 'espagne_hotmail', 'espagne_yahoo')):
        await ajouter_au_panier(update, context, produit_selectionne, 1)

    elif produit_selectionne == 'panier':
        await afficher_panier(update, context)

    elif produit_selectionne == 'profil':
        await afficher_profil(update, context)

    elif produit_selectionne == 'confirmer':
        await confirmer_commande(update, context)

    elif produit_selectionne == 'vider_panier':
        user_id = update.effective_user.id
        panier[user_id] = []
        await query.edit_message_text("🛒 VOTRE PANIER A ÉTÉ VIDÉ.", reply_markup=generer_bouton_retour_menu())
        logger.info(f"Panier vidé pour l'utilisateur {user_id}")

    elif produit_selectionne == 'retirer_article':
        await retirer_article(update, context)

    elif produit_selectionne == 'gerer_utilisateurs':
        await gerer_utilisateurs(update, context)

    elif produit_selectionne == 'voir_statistiques':
        await voir_statistiques(update, context)

    elif produit_selectionne == 'envoyer_credit':
        await envoyer_credit(update, context)

    elif produit_selectionne == 'gerer_admins':
        await gerer_admins(update, context)

    elif produit_selectionne == 'ajouter_admin':
        context.user_data['action'] = 'ajouter_admin'
        await query.edit_message_text("ENTREZ L'ID DE L'UTILISATEUR À AJOUTER COMME ADMIN :", reply_markup=generer_bouton_retour_menu())

    elif produit_selectionne == 'supprimer_admin':
        context.user_data['action'] = 'supprimer_admin'
        await query.edit_message_text("ENTREZ L'ID DE L'UTILISATEUR À RETIRER DES ADMINS :", reply_markup=generer_bouton_retour_menu())

    elif produit_selectionne == 'gerer_codes_promo':
        await gerer_codes_promo(update, context)

    elif produit_selectionne == 'ajouter_promo':
        context.user_data['action'] = 'ajouter_promo'
        await query.edit_message_text("ENTREZ LE CODE PROMO ET LA RÉDUCTION (FORMAT : `CODE_PROMO REDUCTION`) :", reply_markup=generer_bouton_retour_menu())

    elif produit_selectionne == 'supprimer_promo':
        context.user_data['action'] = 'supprimer_promo'
        await query.edit_message_text("ENTREZ LE CODE PROMO À SUPPRIMER :", reply_markup=generer_bouton_retour_menu())

    elif produit_selectionne == 'support':
        await query.edit_message_text(
            "📱 POUR TOUTE ASSISTANCE, VEUILLEZ CONTACTER @leveritablepheno.",
            reply_markup=generer_bouton_retour_menu()
        )

    elif produit_selectionne == 'guide':
        guide_text = (
            "📖 GUIDE D'UTILISATION DU BOT 📖\n\n"
            "1. RECHARGEZ VOTRE CRÉDIT EN UTILISANT L'OPTION 'RECHARGE DE CRÉDIT'.\n"
            "2. CONSULTEZ VOTRE SOLDE DANS 'MON PROFIL'.\n"
            "3. AJOUTEZ DES PRODUITS À VOTRE PANIER ET CONFIRMEZ VOTRE ACHAT.\n"
            "4. PAYEZ EN CRYPTO ET CONTACTEZ LE SUPPORT POUR FINALISER VOTRE COMMANDE."
        )
        await query.edit_message_text(guide_text, reply_markup=generer_bouton_retour_menu())

    elif produit_selectionne == 'promo_code':
        context.user_data['action'] = 'promo'
        await query.edit_message_text("ENTREZ VOTRE CODE PROMO :", reply_markup=generer_bouton_retour_menu())

    elif produit_selectionne == 'menu':
        await start(update, context)

# Fonction pour gérer les admins
async def gerer_admins(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    admin_list = "\n".join([str(admin_id) for admin_id in admins])
    message = f"👑 LISTE DES ADMINS :\n\n{admin_list}"

    keyboard = [
        [InlineKeyboardButton("➕ Ajouter un Admin", callback_data='ajouter_admin')],
        [InlineKeyboardButton("➖ Supprimer un Admin", callback_data='supprimer_admin')],
        [InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await query.edit_message_text(message, reply_markup=reply_markup)

# Fonction pour gérer les codes promos
async def gerer_codes_promo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    codes_promo_list = "\n".join([f"{code}: {reduction}%" for code, reduction in codes_promo.items()])
    message = f"🎁 LISTE DES CODES PROMOS :\n\n{codes_promo_list}"

    keyboard = [
        [InlineKeyboardButton("➕ Ajouter un Code Promo", callback_data='ajouter_promo')],
        [InlineKeyboardButton("➖ Supprimer un Code Promo", callback_data='supprimer_promo')],
        [InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await query.edit_message_text(message, reply_markup=reply_markup)

# Fonction pour afficher le panier
async def afficher_panier(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user_id = update.effective_user.id
    await query.answer()

    if user_id in panier and panier[user_id]:
        panier_message = "\n".join([f"{item['quantite']}x {item['nom_produit']} à {item['total']}€" for item in panier[user_id]])
        total_global = sum(item['total'] for item in panier[user_id])
        message = f"🛒 PANIER :\n{panier_message}\n\n**TOTAL : {total_global}€**"
        keyboard = [
            [InlineKeyboardButton("✅ Confirmer la Commande", callback_data='confirmer')],
            [InlineKeyboardButton("❌ Supprimer le Panier", callback_data='vider_panier')],
            [InlineKeyboardButton("🗑️ Retirer un article", callback_data='retirer_article')],
            [InlineKeyboardButton("↩️ Retour au Menu", callback_data='menu')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
    else:
        message = "🛒 VOTRE PANIER EST VIDE. AJOUTEZ DES PRODUITS POUR CONTINUER."
        reply_markup = generer_bouton_retour_menu()

    await query.edit_message_text(message, reply_markup=reply_markup)

# Fonction pour ajouter un produit au panier sans débiter immédiatement
async def ajouter_au_panier(update: Update, context: ContextTypes.DEFAULT_TYPE, produit_selectionne: str, quantite: int) -> None:
    user_id = update.effective_user.id
    PRIX_PRODUITS = {
        'ups': (125, "UPS 2024 📦"),
        'dhl': (125, "DHL 2024 🚚"),
        'colissimo': (125, "COLISSIMO 2024 📬"),
        'chronopost': (125, "CHRONOPOST 2024 🚀"),
        'netflix': (125, "NETFLIX 2024 🎥"),
        'ameli': (125, "AMELI 2024 🏥"),
        'rdp_1m': (30, "RDP 1 mois + Plesk 🖥️"),
        'rdp_3m': (50, "RDP 3 mois + Plesk 🖥️"),
        'rdp_6m': (90, "RDP 6 mois + Plesk 🖥️"),
        'acheter_netflix_fr': (13, "NETFLIX 13€/k 🎥"),
        'acheter_doctolib': (5, "DUMP DOCTOLIB 5€/k 💉"),
        'acheter_microsoft': (3, "MICROSOFT CHECK 3€/k 🖥️"),
        'acheter_amazon': (1.5, "AMAZON CHECK : 1,50€ 📦"),
        'idf_gmail': (4, "Gmail.com 🇫🇷 - 4€/k"),
        'belgique_hotmail': (4, "Hotmail.be 🇧🇪 - 4€/k"),
        'belgique_live': (4, "Live.be 🇧🇪 - 4€/k"),
        'espagne_hotmail': (4, "Hotmail.es 🇪🇸 - 4€/k"),
        'espagne_yahoo': (4, "Yahoo.es 🇪🇸 - 4€/k"),
    }

    prix, nom_produit = PRIX_PRODUITS[produit_selectionne]
    total = prix * quantite

    if user_id not in panier:
        panier[user_id] = []

    panier[user_id].append({
        "nom_produit": nom_produit,
        "quantite": quantite,
        "total": total
    })

    logger.info(f"{quantite}x {nom_produit} ajoutés au panier de l'utilisateur {user_id}. Total: {total}€")
    await afficher_panier(update, context)

# Fonction pour débiter le solde lors de la confirmation de commande
async def debiter_solde(user_id: int, total: int) -> bool:
    solde_actuel = user_soldes.get(str(user_id), 0)
    if solde_actuel >= total:
        user_soldes[str(user_id)] -= total
        sauvegarder_soldes(user_soldes)
        logger.info(f"Solde de l'utilisateur {user_id} débité de {total}€. Solde restant: {user_soldes[str(user_id)]}€")
        return True
    else:
        return False

# Fonction pour retirer un article spécifique du panier
async def retirer_article(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user_id = update.effective_user.id
    await query.answer()

    if user_id in panier and panier[user_id]:
        item_to_remove = panier[user_id].pop()  # Suppression du dernier article (à adapter)
        await query.edit_message_text("🗑️ ARTICLE RETIRÉ DU PANIER.", reply_markup=generer_bouton_retour_menu())
        logger.info(f"Article retiré du panier de l'utilisateur {user_id}: {item_to_remove}")
        await afficher_panier(update, context)
    else:
        await query.edit_message_text("❌ VOTRE PANIER EST DÉJÀ VIDE.", reply_markup=generer_bouton_retour_menu())

# Fonction pour confirmer la commande et débiter le solde
async def confirmer_commande(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    user_id = update.effective_user.id

    if user_id in panier and panier[user_id]:
        total_global = sum(item['total'] for item in panier[user_id])

        if await debiter_solde(user_id, total_global):
            await query.edit_message_text(
                f"✅ *COMMANDE CONFIRMÉE AVEC SUCCÈS !*\n\n"
                f"**TOTAL DÉBITÉ :** *{total_global}€*",
                reply_markup=generer_bouton_retour_menu()
            )
            logger.info(f"Commande confirmée pour l'utilisateur {user_id}: {total_global}€")
            panier[user_id] = []  # Vider le panier après confirmation
        else:
            await query.edit_message_text(
                "❌ SOLDE INSUFFISANT POUR CETTE COMMANDE. VEUILLEZ RECHARGER VOTRE CRÉDIT.",
                reply_markup=generer_bouton_retour_menu()
            )
    else:
        await query.edit_message_text("❌ VOTRE PANIER EST VIDE. AJOUTEZ DES PRODUITS POUR CONTINUER.", reply_markup=generer_bouton_retour_menu())

# Fonction pour gérer les utilisateurs
async def gerer_utilisateurs(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    utilisateurs_info = "\n".join([f"ID: {uid}, Solde: {solde}€" for uid, solde in user_soldes.items()])
    message = f"📋 LISTE DES UTILISATEURS :\n\n{utilisateurs_info}"

    await query.edit_message_text(message, reply_markup=generer_bouton_retour_menu())

# Fonction pour voir les statistiques
async def voir_statistiques(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    total_utilisateurs = len(user_soldes)
    total_credits = sum(user_soldes.values())
    message = (
        f"📊 STATISTIQUES :\n\n"
        f"NOMBRE TOTAL D'UTILISATEURS : {total_utilisateurs}\n"
        f"TOTAL DES CRÉDITS EN CIRCULATION : {total_credits}€"
    )

    await query.edit_message_text(message, reply_markup=generer_bouton_retour_menu())

# Configuration du bot Telegram
if __name__ == '__main__':

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("Le bot est démarré.")
    app.run_polling()
